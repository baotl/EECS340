struct in_addr {
	unsigned long s_addr;          // Write using inet_pton(), or use a special IP address such as INADDR_ANY.
};
